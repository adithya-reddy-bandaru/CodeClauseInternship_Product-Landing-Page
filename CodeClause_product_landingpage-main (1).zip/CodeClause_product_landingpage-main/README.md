# CodeClause_product_landingpage
 i developed this product landing page of handicrafts using html and css. 
